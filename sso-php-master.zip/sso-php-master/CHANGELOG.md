# Changelog
All Notable changes to `jkd-sso` will be documented in this file

## 0.1.0 - 2020-01-XX

### Added
- Initial release!

### Deprecated
- Nothing

### Fixed
- Nothing

### Removed
- Nothing

### Security
- Nothing
