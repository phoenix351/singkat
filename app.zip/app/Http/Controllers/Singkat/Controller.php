<?php

namespace App\Http\Controllers\Singkat;

abstract class Controller
{
    //
}
